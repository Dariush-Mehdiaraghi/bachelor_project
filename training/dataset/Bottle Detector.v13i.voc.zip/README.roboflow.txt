
Bottle Detector - v13 2021-05-05 12:06am
==============================

This dataset was exported via roboflow.ai on June 11, 2021 at 7:12 PM GMT

It includes 534 images.
Bottles are annotated in Pascal VOC format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:


